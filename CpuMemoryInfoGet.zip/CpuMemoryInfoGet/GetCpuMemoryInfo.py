import os
import sys
import wmi
import time
from ctypes import *
from ctypes.wintypes import *


# 存储内存信息               
class MemoryInfo(Structure):
    _fields_ = [
                ('dwLength', DWORD),
                ('dwMemoryLoad', DWORD),
                ('ullTotalPhys', c_longlong),
                ('ullAvailPhys', c_longlong),
                ('ullTotalPageFile', c_longlong),
                ('ullAvailPageFile', c_longlong),
                ('ullTotalVirtual', c_longlong),
                ('ullAvailVirtual', c_longlong),
                ('ullAvailExtendedVirtual', c_longlong)
                ]
                

def GetRamRunInfo(filename):
    file=open(filename, 'a')
    c_mem=MemoryInfo()
    
    windll.kernel32.GlobalMemoryStatus(byref(c_mem))
    file.write('Used memory percentage: '+str(c_mem.dwMemoryLoad)+'%'+'\n')                                 # 使用物理内存的百分比
    file.write('Physical memory total: '+str(c_mem.ullTotalPhys / (1024 * 1024 * 1024))+' '+'GB'+'\n')      # 物理内存总数, GBytes       
    file.write('Physical memory available: '+str(c_mem.ullAvailPhys / (1024 * 1024 * 1024))+' '+'GB'+'\n')  # 可用内存总数, GBytes
    
    file.close()
    

def GetCpuRunInfo(filename, c_wmi):
    file=open(filename, 'a')
    
    for cpu in c_wmi.Win32_Processor():            
            file.write('CPU Utilization: '+str(cpu.DeviceID)+': '+str(cpu.LoadPercentage)+'%'+'\n')
            
    file.close()

            
def GetSysRunInfo(filename, c_wmi, times, wait_times):
    'Get CPU and MEMORY usage information!'
    
    i=0
    
    while (i < times):
        file=open(filename, 'a')
        
        timestamp = time.strftime('%a, %d %b %Y %H:%M:%S', time.localtime())
        file.write(str(timestamp)+'\n')
        
        file.close()
        
        GetCpuRunInfo(filename, c_wmi)
        GetRamRunInfo(filename)        
        
        file=open(filename, 'a')
        file.write('\n')
        file.write('\n')
        file.close()                    # close the file
        
        i=i+1
        
        time.sleep(wait_times)          # wait a few seconds
        
        
    
if __name__ == '__main__':          #
    print('CPU and MEMORY usage information record is running!')
    
    timeinfo=time.strftime('%Y-%m-%d-%H-%M-%S', time.localtime(time.time()))
    filename='SysRunInfo-'+str(timeinfo)+'.log'
    
    c_wmi=wmi.WMI()
    times=100000000     # 循环查询的总次数
    wait_times=3        # 每隔多长时间查询一次，单位：s    
    
    GetSysRunInfo(filename, c_wmi, times, wait_times)   

    print('Recording Stopped!')
    
    
    os.system('pause')
    
    
    
    
    