# -*- coding: utf-8 -*-

import os, sys


def rename_files(old_path, new_path):
    '将old_path文件夹下的文件重命名并保存到new_path文件夹下！'
    
    filelist = os.listdir(old_path) # 获取old_path文件夹下的所有文件，包括文件夹，存储在列表中
    
    for file in filelist:           # 遍历所有的文件
        oldname = os.path.join(old_path, file) # 原来文件的完整路径，包含文件名
        if os.path.isdir(oldname):  # 判断是文件夹还是文件
            continue
            
        filename = os.path.splitext(file)[0] # 获取当前文件的文件名
        filetype = os.path.splitext(file)[1] # 获取当前文件的扩展名
        newname  = os.path.join(new_path, share_name + str(filelist.index(file)) + filetype)
        
        #for example: 将c:\old\text.txt 修改为 c:\new\text_0.txt
        os.rename(oldname, newname)
        
        
if __name__ == '__main__':

    'Python to modify files name!'
    
    path = sys.path[0]                      # 获取当前脚本所在的路径
    old_path   = os.path.join(path, 'old')  # 获取当前脚本路径下存放旧文件的文件夹的路径
    new_path   = os.path.join(path, 'new')  # 获取当前脚本路径下存放新文件的文件夹的路径
    share_name = 'Hony-li_'                 # 设置新修改后的文件共享的文件名

    print(old_path)
    print(new_path)
    
    rename_files(old_path, new_path)
    
    os.system('pause')
